﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROJETOTECHBOOMCURSOS
{
    public class Controle
    {
        public bool tem;
        public String mensagem = "";
        public bool acessar (String login , String senha)
        {
            comandos novoLogin = new comandos();
            tem = novoLogin.verificarLogin(login, senha);
            if (!novoLogin.mensagem.Equals(""))
            {
                this.mensagem = novoLogin.mensagem;
            }
            return tem;
        }
        public String cadastrar (String email , String senha,String confSenha)
        {
            comandos novoLogin = new comandos();
           this.mensagem = novoLogin.cadastrar(email,senha,confSenha);
            if (novoLogin.tem)
            {
                this.tem = true;
            }
            return mensagem;
        }

    }
}
