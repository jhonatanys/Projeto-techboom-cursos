﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROJETOTECHBOOMCURSOS
{
    public partial class Pagina_de_Cursos : Form
    {
        public Pagina_de_Cursos()
        {
            InitializeComponent();
        }
    }
}
